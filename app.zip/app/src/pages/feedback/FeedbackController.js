(function(){

  angular
       .module('feedback')
       .controller('FeedbackController', [
          'feedbackService', '$mdBottomSheet', '$q', '$scope',
          FeedbackController
       ]);

  /**
   * Feedback Controller for the Angular Material Starter App
   * @param $scope
   * @param $mdSidenav
   * @param avatarsService
   * @constructor
   */
  function FeedbackController(feedbackService, $mdBottomSheet, $q, $scope) {
    console.log('--feedbackController')

    var self = this;

    self.content        = {};
    self.showContactOptions = showContactOptions;

    self.showFeedbackForm = false;
    $scope.data = {};
    $scope.data.feedback = "Leave your feed back here.";

    feedbackService
          .loadContent()
          .then( function( content ) {
            self.content    = content;
          });

    $scope.showFeedbackForm = function() {
       console.log('-- form')
       self.showFeedbackForm = !self.showFeedbackForm;
    }

    $scope.checkData = function() {
       console.log($scope.data.feedback);
    }

    /**
     * Show the bottom sheet
     */
    function showContactOptions($event) {
        var user = self.selected;

        return $mdBottomSheet.show({
          templateUrl: './src/pages/feedback/view/share.html',
          controller: [ '$mdBottomSheet', ContactPanelController],
          controllerAs: "cp",
          bindToController : true,
          targetEvent: $event
        }).then(function(clickedItem) {
          clickedItem && $log.debug( clickedItem.name + ' clicked!');
        });

        /**
         * Bottom Sheet controller for the Avatar Actions
         */
        function ContactPanelController( $mdBottomSheet ) {
          this.user = user;
          this.actions = [
            { name: 'Phone'       , icon: 'phone'       , icon_url: 'assets/svg/phone.svg'},
            { name: 'Twitter'     , icon: 'twitter'     , icon_url: 'assets/svg/twitter.svg'},
            { name: 'Google+'     , icon: 'google_plus' , icon_url: 'assets/svg/google_plus.svg'},
            { name: 'Hangout'     , icon: 'hangouts'    , icon_url: 'assets/svg/hangouts.svg'}
          ];
          this.submitContact = function(action) {
            $mdBottomSheet.hide(action);
          };
        }
    }
  }
})();
