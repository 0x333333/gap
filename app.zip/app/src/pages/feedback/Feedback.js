(function(){
  'use strict';

  // Prepare the 'feedback' module for subsequent registration of controllers and delegates
  angular.module('feedback', [ 'ngMaterial', 'ngRoute' ]);

  console.log('--feedback')

})();
