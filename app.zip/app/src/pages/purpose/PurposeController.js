(function(){

  angular
       .module('purpose')
       .controller('PurposeController', [
          PurposeController
       ]);

  /**
   * Controller
   * @constructor
   */
  function PurposeController() {
    var self = this;

    /**
     * No functionality here
     */
  }
})();
