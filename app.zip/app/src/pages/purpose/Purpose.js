(function(){
  'use strict';

  // Prepare the 'purpose' module for subsequent registration of controllers and delegates
  angular.module('purpose', [ 'ngMaterial', 'ngRoute' ]);


})();
