(function(){
  'use strict';

  // Prepare the 'menu' module for subsequent registration of controllers and delegates
  angular.module('menu', [ 'ngMaterial' ]);


})();
